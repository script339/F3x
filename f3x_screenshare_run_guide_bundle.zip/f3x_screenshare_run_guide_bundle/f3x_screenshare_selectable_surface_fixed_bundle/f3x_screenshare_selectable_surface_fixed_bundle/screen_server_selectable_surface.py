# language: Python 3.10+ | file: screen_server_52k.py | target: Windows 10/11
# WebSocket screen capture server for F3X Screen Share Turbo Color (304x171 source grid)
# compatible with websockets 10.x through 17.x

import asyncio
import mss
import cv2
import numpy as np
import json
import time
import traceback
import sys

# ─── Config ──────────────────────────────────────────────────────────────────
GRID_W     = 304
GRID_H     = 171
QUANT      = 4      # modest quantization reduces tiny color changes; use 1 for max color fidelity
TARGET_FPS = 15     # capture target; the Roblox server may apply colors more slowly
PORT       = 8080

prev_frame = None

# ─── Frame pipeline ──────────────────────────────────────────────────────────

def grab_delta(sct, mon):
    global prev_frame
    try:
        raw   = sct.grab(mon)
        frame = np.frombuffer(raw.bgra, dtype=np.uint8).reshape(raw.height, raw.width, 4)
        frame = cv2.resize(frame[:, :, :3], (GRID_W, GRID_H), interpolation=cv2.INTER_AREA)
        frame = frame[:, :, ::-1].copy()
        if QUANT > 1:
            # Round to the nearest quantization step (rather than always darkening).
            frame = np.clip(((frame.astype(np.uint16) + QUANT // 2) // QUANT) * QUANT, 0, 255).astype(np.uint8)

        if prev_frame is None:
            prev_frame = np.full_like(frame, 255)

        diff   = np.any(frame != prev_frame, axis=2)
        ys, xs = np.where(diff)
        prev_frame = frame.copy()

        if len(xs) == 0:
            return None

        # One vectorized packing step avoids building separate Python coordinate/color lists.
        return np.column_stack((xs, ys, frame[ys, xs])).tolist()

    except Exception as e:
        print(f"[grab_delta error] {e}")
        return None

# ─── WebSocket handler ────────────────────────────────────────────────────────

async def stream_handler(websocket):
    global prev_frame
    prev_frame = None

    try:
        addr = websocket.remote_address
    except Exception:
        addr = "unknown"

    print(f"[WS] client connected: {addr}")
    interval = 1.0 / TARGET_FPS

    try:
        with mss.MSS() as sct:
            mon = sct.monitors[1]
            while True:
                t0    = time.perf_counter()
                delta = grab_delta(sct, mon)

                if delta is not None:
                    payload = json.dumps(delta, separators=(',', ':'))
                    await websocket.send(payload)

                elapsed = time.perf_counter() - t0
                await asyncio.sleep(max(0.0, interval - elapsed))

    except Exception as e:
        print(f"[WS] client disconnected: {e}")

# ─── Version-safe serve ──────────────────────────────────────────────────────

async def main():
    import websockets

    ver_str = websockets.__version__
    ver     = tuple(int(x) for x in ver_str.split(".")[:2])
    print(f"[ScreenShare] websockets v{ver_str}")
    print(f"[ScreenShare] {GRID_W}x{GRID_H} grid | {TARGET_FPS}fps capture target | QUANT={QUANT} | port {PORT}")
    print(f"[ScreenShare] waiting for Lua client on ws://localhost:{PORT} ...")
    print(f"[ScreenShare] press Ctrl+C to stop\n")

    try:
        if ver >= (14, 0):
            from websockets.asyncio.server import serve
        else:
            from websockets.server import serve

        async with serve(stream_handler, "0.0.0.0", PORT):
            await asyncio.Future()

    except OSError as e:
        print(f"\n[ERROR] Could not bind to port {PORT}: {e}")
        print(f"        Is another process using port {PORT}? Try closing it or change PORT in config.")
        sys.exit(1)

if __name__ == "__main__":
    try:
        import websockets
        print(f"[check] mss        ok")
        print(f"[check] cv2        ok  (version {cv2.__version__})")
        print(f"[check] numpy      ok  (version {np.__version__})")
        print(f"[check] websockets ok  (version {websockets.__version__})")
        print()

        asyncio.run(main())

    except ImportError as e:
        print(f"\n[MISSING DEP] {e}")
        print("Run: py -m pip install mss opencv-python-headless numpy websockets")
        input("Press Enter to exit...")
        sys.exit(1)

    except KeyboardInterrupt:
        print("\n[ScreenShare] stopped by user.")

    except Exception as e:
        print(f"\n[CRASH] {e}")
        traceback.print_exc()
        input("\nPress Enter to exit...")
        sys.exit(1)
