# F3X Screen Share - selectable physical screen surface launcher
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
$deps = @("websockets", "mss", "opencv-python-headless", "numpy")
Write-Host "[setup] checking dependencies..." -ForegroundColor Cyan
foreach ($pkg in $deps) {
    $check = py -m pip show $pkg 2>&1
    if ($LASTEXITCODE -ne 0 -or $check -match "not found") {
        Write-Host "  installing $pkg..." -ForegroundColor Yellow
        py -m pip install $pkg --quiet
    } else {
        Write-Host "  $pkg ok" -ForegroundColor Green
    }
}
Write-Host ""
Write-Host "[launch] starting screen_server_selectable_surface.py..." -ForegroundColor Cyan
Write-Host "[launch] capture source 304x171 | ws://localhost:8080" -ForegroundColor Green
Set-Location $PSScriptRoot
py screen_server_selectable_surface.py
