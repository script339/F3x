F3X Screen Share - Selectable Surface Input Fix

Files:
- f3x_screenshare_selectable_surface.lua: updated selector using UserInputService + camera raycast, with a visible orange outline on successful selection.
- screen_server_selectable_surface.py: matching 304x171 capture server.
- launch_selectable_surface.ps1: dependency check and server launcher.

Use:
1. Stop any previous capture server with Ctrl+C.
2. Run launch_selectable_surface.ps1.
3. Run f3x_screenshare_selectable_surface.lua in the environment you normally use with F3X.
4. In Control, click Select Screen Part.
5. Move the cursor onto the actual 3D face you want covered, outside the Rayfield window, and left-click once.
6. Look for the orange outline and the "Screen Surface Selected" notification naming the part and face.
7. Remove any old canvas, choose the grid preset and Max Parts limit in Settings, then Build Screen and Enable Stream.

Notes:
- This is a physical BasePart surface selector. It does not select a GUI object or a decal/image surface.
- A maximum 52K canvas is very heavy and may take a long time to build and update, especially in multiplayer.
- Selection and F3X behavior depend on the executor, tool implementation, and permissions in the experience. This hasn't been live-tested in your Roblox session.
